"""Randomized test: vectorized eTaPR (src/metrics.py) vs. a loop-based mirror of the official eTaPR_pkg v22.6.1 structure
(per-pair overlap matrix, set-based iterative pruning, per-prediction weighted precision). delta = 0."""
import sys, math, numpy as np
sys.path.insert(0, "src")
from metrics import etapr

def to_ranges(stream):                       # mirrors File_IO.load_stream_2_range
    out, start, prev = [], -1, -2
    for i, v in enumerate(stream):
        if v == 1 and prev in (0, -2): start = i
        elif v == 0 and prev == 1: out.append((start, i - 1))
        prev = v
    if prev == 1: out.append((start, len(stream) - 1))
    return out

def mirror(y, yp, theta_p, theta_r):
    A, P = to_ranges(list(y)), to_ranges(list(yp))
    if not A or not P: return 0.0, 0.0, 0.0
    w = [math.sqrt(e - s + 1) for s, e in P]; W = sum(w)
    M = np.zeros((len(A), len(P)))
    for i, (a0, a1) in enumerate(A):
        for j, (p0, p1) in enumerate(P):
            M[i, j] = sum(1 for t in range(a0, a1 + 1) if p0 <= t <= p1)      # uniform overlap score, no ambiguous tail
    maxA = np.array([a1 - a0 + 1 for a0, a1 in A], float); maxP = np.array([p1 - p0 + 1 for p0, p1 in P], float)
    E = M.copy()
    while True:
        tars = E.sum(1) / maxA; ea = set(np.where(tars < theta_r)[0]) - set(np.where(tars == 0)[0])
        for i in ea: E[i] = 0
        taps = E.sum(0) / maxP; ep = set(np.where(taps < theta_p)[0]) - set(np.where(taps == 0)[0])
        for j in ep: E[:, j] = 0
        if not ea and not ep: break
    r = E.sum(1) / maxA; rd = np.where(r >= theta_r, 1.0, 0.0); rp = np.minimum(r, 1.0)
    tar = ((rd + rd * rp) / 2).mean()
    p = E.sum(0) / maxP; pdd = np.where(p >= theta_p, 1.0, 0.0)
    tap = sum(w[j] * (pdd[j] + pdd[j] * p[j]) / 2 for j in range(len(P))) / W
    return tap, tar, (0.0 if tap + tar == 0 else 2 * tap * tar / (tap + tar))

rng = np.random.default_rng(1); worst = 0.0; n = 0
for trial in range(3000):
    T = int(rng.integers(20, 400))
    y = (rng.random(T) < rng.uniform(0.01, 0.15)).astype(int)
    y = (np.convolve(y, np.ones(int(rng.integers(1, 25))), "same") > 0).astype(int)     # attack intervals of varied length
    yp = (rng.random(T) < rng.uniform(0.005, 0.3)).astype(int)
    yp = (np.convolve(yp, np.ones(int(rng.integers(1, 15))), "same") > 0).astype(int)
    for tp, tr in ((0.5, 0.1), (0.7, 0.1), (0.3, 0.01)):
        a = etapr(y, yp, tp, tr); b = mirror(y, yp, tp, tr)
        worst = max(worst, abs(a["eTaP"] - b[0]), abs(a["eTaR"] - b[1]), abs(a["eTaF1"] - b[2])); n += 1
print(f"{n} random cases; max absolute difference in eTaP/eTaR/eTaF1: {worst:.2e}")
assert worst < 1e-9
