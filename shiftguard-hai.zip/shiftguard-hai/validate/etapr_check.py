"""Compare our eTaPR re-implementation (src/metrics.py) with the official eTaPR package (v22.6.1) on random streams.

Usage (from the repository root):
    1) get the official package from https://github.com/icsdataset/hai (folder 'etapr_pkg' / eTaPR-22.6.1),
       e.g.  pip install eTaPR-22.6.1-py3-none-any.whl     (or put the folder containing 'eTaPR_pkg' on PYTHONPATH)
    2) python validate/etapr_check.py
Output: results/etapr_validation.csv and the largest absolute differences (expected: ~1e-15).
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "src")
from metrics import etapr as ours
from eTaPR_pkg import etapr as ref

rng = np.random.default_rng(0); rows = []
for case in range(2000):
    n = int(rng.integers(200, 3000)); y = np.zeros(n, int); yp = np.zeros(n, int)
    for _ in range(int(rng.integers(1, 6))):                      # attack intervals
        a = int(rng.integers(0, n - 50)); y[a:a + int(rng.integers(5, 200))] = 1
    for _ in range(int(rng.integers(0, 10))):                     # alarm intervals
        a = int(rng.integers(0, n - 20)); yp[a:a + int(rng.integers(1, 150))] = 1
    a = ours(y, yp, 0.5, 0.1)
    b = ref.evaluate_w_streams(list(y), list(yp), theta_p=0.5, theta_r=0.1, delta=0.0)
    rows.append(dict(case=case, ours_P=a["eTaP"], ref_P=b["eTaP"], ours_R=a["eTaR"], ref_R=b["eTaR"], ours_F1=a["eTaF1"], ref_F1=b["f1"]))
df = pd.DataFrame(rows)
for k in ("P", "R", "F1"): df[f"absdiff_{k}"] = (df[f"ours_{k}"] - df[f"ref_{k}"]).abs()
df.to_csv("results/etapr_validation.csv", index=False)
print("cases:", len(df), "max |diff| eTaP, eTaR, eTaF1:", df.absdiff_P.max(), df.absdiff_R.max(), df.absdiff_F1.max())
